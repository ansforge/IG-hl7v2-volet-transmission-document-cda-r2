# ans.hl7v2.fr.trans-cda-r2#2.1.3: Volet de transmission d'un document CDA-R2 en HL7v2

## Pages

* [Accueil](index.md)
* [Error codes](error-codes.md)
* [Mapping VIHF et XDS](mapping.md)
* [Table AckMetierZAM](ack-metier-zam.md)
* [Téléchargements](download.md)
* [Artifacts Summary](artifacts.md)
* [Exemples de messages](exemples.md)
* [Volume 2 : Détail des transactions](volume2.md)
* [Table MetaDMP/MSS](meta-dmp-mss.md)
* [Test](testplan.md)
* [Documents de référence](doc-ref.md)
* [Historique des versions](change-log.md)
* [Mapping message MSS](mapping-mss.md)
* [Lien entre l'en-tête CDA et les métadonnées XDS](lien-entete-cda-meta-xds.md)
* [Volume 1 : Etude fonctionnelle](volume1.md)
* [Glossaire](glossaire.md)

## Resources

### ImplementationGuides

* [Volet de transmission d'un document CDA-R2 en HL7v2](index.md)
