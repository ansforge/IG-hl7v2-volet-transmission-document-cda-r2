# ans.hl7v2.fr.trans-cda-r2#2.1.3: Volet de transmission d'un document CDA-R2 en HL7v2

## Pages

* [Accueil](index.md)
* [Lien entre l'en-tête CDA et les métadonnées XDS](lien-entete-cda-meta-xds.md)
* [Table MetaDMP/MSS](meta-dmp-mss.md)
* [Glossaire](glossaire.md)
* [Mapping message MSS](mapping-mss.md)
* [Mapping VIHF et XDS](mapping.md)
* [Error codes](error-codes.md)
* [Artifacts Summary](artifacts.md)
* [Volume 2 : Détail des transactions](volume2.md)
* [Exemples de messages](exemples.md)
* [Téléchargements](download.md)
* [Documents de référence](doc-ref.md)
* [Test](testplan.md)
* [Historique des versions](change-log.md)
* [Table AckMetierZAM](ack-metier-zam.md)
* [Volume 1 : Etude fonctionnelle](volume1.md)

## Resources

### ImplementationGuides

* [Volet de transmission d'un document CDA-R2 en HL7v2](index.md)
