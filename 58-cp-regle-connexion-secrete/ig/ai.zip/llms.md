# ans.hl7v2.fr.trans-cda-r2#2.1.3: Volet de transmission d'un document CDA-R2 en HL7v2

## Pages

* [Accueil](index.md)
* [Lien entre l'en-tête CDA et les métadonnées XDS](lien-entete-cda-meta-xds.md)
* [Mapping VIHF et XDS](mapping.md)
* [Table MetaDMP/MSS](meta-dmp-mss.md)
* [Error codes](error-codes.md)
* [Téléchargements](download.md)
* [Historique des versions](change-log.md)
* [Artifacts Summary](artifacts.md)
* [Volume 2 : Détail des transactions](volume2.md)
* [Glossaire](glossaire.md)
* [Mapping message MSS](mapping-mss.md)
* [Volume 1 : Etude fonctionnelle](volume1.md)
* [Test](testplan.md)
* [Exemples de messages](exemples.md)
* [Table AckMetierZAM](ack-metier-zam.md)
* [Documents de référence](doc-ref.md)

## Resources

### ImplementationGuides

* [Volet de transmission d'un document CDA-R2 en HL7v2](index.md)
